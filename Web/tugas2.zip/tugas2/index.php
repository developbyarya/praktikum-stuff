<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="style.css" />

    <title>Order your menu! - WIMAYA CAFE</title>
  </head>
  <body class="p-4">
    <div class="row mx-5 card-bg rounded-3">
      <div class="col g-0">
        <img
          src="./lebih-bagus.jpg"
          alt="wimaya coffee"
          class="image rounded rounded-3 w-100 h-100"
        />
      </div>
      <div class="col py-3 ml-3">
        <form action="result.php" method="get" class="">
          <h1 class="text-center">Input Your Order</h1>
          <select name="menu" id="menu" class="form-select">
            <option value="americano" selected>Americano</option>
            <option value="mochachino">mochachino</option>
            <option value="hazelnut latte">Hazelnut Latte</option>
            <option value="Vanila latte">Vanila Latte</option>
            <option value="salted caramel">Salted Caramel</option>
          </select>
          <div class="row">
            <div class="input-section col d-flex flex-column">
              <h2>Hot/Ice</h2>
              <div class="d-flex gap-3">
                <div class="radio-group">
                  <input
                    type="radio"
                    id="radio-hot"
                    value="hot"
                    name="hot/ice"
                  />
                  <label for="radio-hot">Hot</label>
                </div>
                <div class="radio-group">
                  <input
                    type="radio"
                    id="radio-ice"
                    value="ice"
                    name="hot/ice"
                    id="flex"
                    checked
                  />
                  <label for="radio-ice">Ice</label>
                </div>
              </div>
            </div>
            <div class="d-flex input-section col flex-column">
              <h2>Size</h2>
              <div class="d-flex gap-3">
                <div class="radio-group">
                  <input
                    type="radio"
                    id="size-regular"
                    value="regular"
                    name="Size"
                  />
                  <label for="size-regular">Regular</label>
                </div>
                <div class="radio-group">
                  <input
                    type="radio"
                    id="size-large"
                    value="large"
                    name="Size"
                    checked
                  />
                  <label for="size-large">Large</label>
                </div>
              </div>
            </div>
          </div>
          <div class="d-flex input-section flex-column">
            <h2>Sweetness Level</h2>
            <div class="d-flex gap-3">
              <div class="radio-group">
                <input type="radio" name="sweetness" id="sweet-normal" value="normal" checked/>
                <label for="sweet-normal">Normal</label>
              </div>
              <div class="radio-group">
                <input type="radio" name="sweetness" id="sweet-less" value="less" />
                <label for="sweet-less">Less Sweet</label>
              </div>
            </div>
          </div>
          <div class="d-flex input-section flex-column">
            <h2>Diary <span class="text-secondary fs-6">(Optional)</span></h2>
            <div class="d-flex gap-3">
              <div class="radio-group">
                <input type="radio" name="diary" value="milk" id="diary-milk" />
                <label for="diary-milk">Milk</label>
              </div>
              <div class="radio-group">
                <input type="radio" value="oat" name="diary" id="diary-oat" />
                <label for="diary-oat">Oat Milk</label>
              </div>
              <div class="radio-group">
                <input type="radio" name="diary" id="diary-almond" value="almond" />
                <label for="diary-almond">Almond</label>
              </div>
            </div>
          </div>
          <h2>Topping</h2>
          <div class="row w-100">
            <div class="d-flex gap-1 col">
              <input type="checkbox" name="toppings[]" value="caramel-sauce" id="topping-caramel" />
              <label for="topping-caramel">Caramel sauce</label>
            </div>
            <div class="d-flex gap-1 col">
              <input
                value="caramel-crumble"
                type="checkbox"
                name="toppings[]" 
                id="topping-caramel-crumble"
              />
              <label for="topping-caramel-crumble">Caramel crumble</label>
            </div>
          </div>
          <div class="row">
            <div class="d-flex gap-1 col">
              <input
                value="choco-granola"
                type="checkbox"
                name="toppings[]" 
                id="topping-choco-granola"
              />
              <label for="topping-choco-granola">Choco Granola</label>
            </div>
            <div class="d-flex gap-1 col">
              <input type="checkbox" value="sea-salt-cream" name="toppings[]" id="topping-sea-salt" />
              <label for="topping-sea-salt">Sea Salt Cream</label>
            </div>
          </div>
          <h2>Note</h2>
          <textarea
            name="additional-note"
            id=""
            style="resize: none"
            class="h-25 bg-dark text-white rounded-3"
            placeholder="add note"
          ></textarea>
          <button type="submit" class="btn-success rounded-pill py-2">
            Submit
          </button>
          <button
            class="btn-dark bg-transparent rounded-pill border-light py-2 text-white"
            type="reset"
          >
            Reset
          </button>
        </form>
      </div>
    </div>

    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
      crossorigin="anonymous"
    ></script>
  </body>
</html>
