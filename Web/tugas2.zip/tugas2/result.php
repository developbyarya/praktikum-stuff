<?php
$coffee_prices = [
    'americano' => [
        'tax' => 0.1,
        'price' => 12000,
    ],
    'mochachino' => [
        'tax' => 0.1,
        'price' => 15000,
    ],
    'keyhazelnut latte' => [
        'tax' => 0.15,
        'price' => 20000,
    ],
    'Vanila latte' => [
        'tax' => 0.15,
        'price' => 17000,
    ],
    'salted caramel' => [
        'tax' => 0.15,
        'price' => 18000,
    ],
];

$additional_price = [
    'regular' => 0,
    'large' => 5000,
    'milk' => 5000,
    'oat' => 6000,
    'almond' => 7000,
    'caramel_sauce' => 3000,
    'caramel_crumble' => 3000,
    'choco-granola' => 4000,
    'sea-salt-cream' => 5000,

];
$total_price = 0;

function price_after_tax($price, $tax)
{
    return $price + $price * $tax;
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css"
        rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC"
        crossorigin="anonymous" />
    <link rel="stylesheet" href="style.css">
    <title>Order Reciept - Wimaya Cafe</title>
</head>

<body>
    <div class="container w-75">
        <h1 class="text-center my-4 text-white">Receipt</h1>
        <table class="table table-dark table-striped">
            <tr>
                <th>Addons</th>
                <th>Description</th>
                <th>Price</th>
                <th>Tax</th>
                <th>Total</th>
            </tr>
            <tr>
                <th>Beverages</th>
                <td><?= $_GET["menu"] ?></td>
                <td>Rp. <?= $coffee_prices[$_GET["menu"]]["price"] ?></td>
                <td><?= $coffee_prices[$_GET["menu"]]["tax"] * 100 ?>%</td>
                <td>Rp. <?= price_after_tax($coffee_prices[$_GET["menu"]]["price"], $coffee_prices[$_GET["menu"]]["tax"]) ?></td>
                <?php
                $total_price += price_after_tax($coffee_prices[$_GET["menu"]]["price"], $coffee_prices[$_GET["menu"]]["tax"]);
                ?>
            </tr>

            <tr>
                <th>Hot/Ice</th>
                <td><?= $_GET["hot/ice"] ?></td>
                <td>-</td>
                <td>-</td>
                <td>-</td>
            </tr>

            <tr> 
                <th>Size</th>
                <td><?= $_GET["Size"] ?></td>
                <td>Rp. <?= $additional_price[$_GET["Size"]] ?></td>
                <td>-</td>
                <td>Rp. <?= $additional_price[$_GET["Size"]] ?></td>
                <?php
                $total_price += $additional_price[$_GET["Size"]];
                ?>
            </tr>
            <tr>
                <th>Sweetness</th>
                <td><?= $_GET["sweetness"] ?></td>
                <td>-</td>
                <td>-</td>
                <td>-</td>
            </tr>
            <?php if (isset($_GET["diary"])): ?>
                <tr>
                    <th>Diary:</th>
                    <td><?= $_GET["diary"] ?></td>
                    <td>Rp. <?= $additional_price[$_GET["diary"]] ?></td>
                    <td>-</td>
                    <td>Rp. <?= $additional_price[$_GET["diary"]] ?></td>
                    <?php
                    $total_price += $additional_price[$_GET["diary"]];
                    ?>
                </tr>
            <?php endif; ?>
            <?php if (isset($_GET["toppings"])): ?>
                <th rowspan="<?=sizeof($_GET["toppings"])+1?>">Toppings</th>
                <?php foreach ($_GET["toppings"] as $topping): ?>
                <tr>
                    <td><?= $topping ?></td>
                    <td>Rp. <?= $additional_price[$topping] ?></td>
                    <td>-</td>
                    <td>Rp. <?= $additional_price[$topping] ?></td>
                    <?php
                    $total_price += $additional_price[$topping];
                    ?>
                </tr>
                <?php endforeach;?>
            <?php endif; ?>

            <tr>
                <th colspan="4" class="text-center"> Total </th>
                <th>Rp. <?= $total_price ?></th>
            </tr>
        </table>
        <a href="/" class="btn btn-primary text-center">Order Again</a>
    </div>
    <script
        src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
        crossorigin="anonymous"></script>
</body>

</html>